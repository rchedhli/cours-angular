import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-post-list-item',
  templateUrl: './post-list-item.component.html',
  styleUrls: ['./post-list-item.component.scss']
})
export class PostListItemComponent implements OnInit {
  @Input() title : String;
  @Input() content : String;
  @Input() created_at : Date;
  loveIts = 0;
  constructor() { }

  ngOnInit() {
  }

  loveIt(){
  this.loveIts++;
  }

  dontLoveIt(){
    this.loveIts--;
  }
}
