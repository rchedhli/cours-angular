import { Injectable } from '@angular/core';
import { Post } from '../models/post.model';
import { Subject } from 'rxjs';
import * as firebase from 'firebase';
import DataSnapshot = firebase.database.DataSnapshot;



@Injectable()
export class PostsService {

  posts : Post[] = [];
  postsSubject = new Subject<Post[]>();
  
  emitPosts() {
    this.postsSubject.next(this.posts);
  }
  savePosts() {
    firebase.database().ref('/posts').set(this.posts);
}

getPosts() {
  firebase.database().ref('/posts')
    .on('value', (data: DataSnapshot) => {
        this.posts = data.val() ? data.val() : [];
        this.emitPosts();
      }
    );
}
  constructor() { 
    this.getPosts();
  }

  addPost(post: Post){
    this.posts.push(post);
    this.savePosts();
    this.emitPosts();
  }

  removePost(post: Post){
    const postIndexToRemove = this.posts.findIndex(
      (postl) => {
        if(postl === post) {
          return true;
        }
      }
    );
    this.posts.splice(postIndexToRemove, 1);
    this.savePosts();
    this.emitPosts();
  }


  loveItPost(post: Post){
    post.loveIts = post.loveIts + 1;
    this.savePosts();
    this.emitPosts();

  }

  dontLoveItPost(post: Post){
    post.loveIts = post.loveIts - 1;
    this.savePosts();
    this.emitPosts();

  }

}
