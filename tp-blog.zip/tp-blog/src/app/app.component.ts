import { Component } from '@angular/core';
import * as firebase from 'firebase';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'tp-blog';

  constructor() {
    const config = {
      apiKey: "AIzaSyCJAGYuVgFfCRyQBWlrd5aP-qIotXmmN6M",
      authDomain: "project-angular-post.firebaseapp.com",
      databaseURL: "https://project-angular-post.firebaseio.com",
      projectId: "project-angular-post",
      storageBucket: "project-angular-post.appspot.com",
      messagingSenderId: "1084778495647",
      appId: "1:1084778495647:web:97d49851ca5ad60ab9acaa",
      measurementId: "G-1Z59K5Q95M"
    };
    
    firebase.initializeApp(config);
  }
}
