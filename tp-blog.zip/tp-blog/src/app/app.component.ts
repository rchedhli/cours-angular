import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'tp-blog';

  posts = [
    {
      title: 'Mon premier post',
      content: "La règle d'or de la conduite est la tolérance mutuelle, car nous ne penserons jamais tous de la même façon, nous ne verrons qu'une partie de la vérité et sous des angles différents.",
      loveIts: 0,
      created_at: '01/02/2019'
    },
    {
      title: 'Mon deuxième post',
      content: "Il ne faut avoir aucun regret pour le passé, aucun remords pour le présent, et une confiance inébranlable pour l'avenir.",
      loveIts: 0,
      created_at: '01/02/2019'
    },
    {
      title: 'Mon dernier post',
      content: "Il n'existe que deux choses infinies, l'univers et la bêtise humaine... mais pour l'univers, je n'ai pas de certitude absolue.",
      loveIts: 0,
      created_at: '01/02/2019'
    }
  ];
}
