export class Post{

    constructor(public title: String, public content: String, public created_at: number, public loveIts: number){
    }

}